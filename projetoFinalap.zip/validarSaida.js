let consultarSaida = document.getElementById('consultarSaida');
let atualizarSaida = document.getElementById('atualizarSaida');
let res = document.getElementById('res');

consultarSaida.addEventListener('click', (e) => {
    e.preventDefault();

    let codSaida = document.getElementById('codSaida').value;

    fetch(`http://localhost:8081/saida/${codSaida}`)
    .then(res => res.json())
    .then(dados => {
        if (dados && dados.id) {
            document.getElementById('nomeAluno').value = dados.nomeAluno;
            document.getElementById('motivo').value = dados.motivo;
            document.getElementById('status').value = dados.status || 'PENDENTE';
            res.innerText = '';
        } else {
            res.innerText = `Saída com ID ${codSaida} não encontrada.`;
        }
    })
    .catch((err) => {
        console.error('Erro ao consultar saída:', err);
        res.innerText = `Erro ao consultar saída com ID ${codSaida}.`;
    });
});

atualizarSaida.addEventListener('click', (e) => {
    e.preventDefault();

    let codSaida = document.getElementById('codSaida').value;
    let status = document.getElementById('status').value;

    const dadosAtualizados = {
        status
    };

    fetch(`http://localhost:8081/saida/${codSaida}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dadosAtualizados)
    })
    .then(res => {
        if (!res.ok) {
            throw new Error('Erro ao atualizar saída');
        }
        return res.json();
    })
    .then(data => {
        res.innerText = 'Saída atualizada com sucesso!';
    })
    .catch((err) => {
        console.error('Erro ao atualizar saída:', err);
        res.innerText = 'Erro ao atualizar saída.';
    });
});
