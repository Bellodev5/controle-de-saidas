document.addEventListener('DOMContentLoaded', () => {
    const filaContainer = document.getElementById('filaSaidas');

    fetch('http://localhost:8081/saida')
      .then(res => {
        if (!res.ok) throw new Error('Erro ao buscar saídas');
        return res.json();
      })
      .then(saidas => {
        const pendentes = saidas.filter(s => s.status.toLowerCase() === 'pendente');
  
        if (pendentes.length === 0) {
          filaContainer.innerHTML = '<p>Nenhuma saída pendente.</p>';
          return;
        }
  
        filaContainer.innerHTML = '';
        pendentes.forEach(saida => {
          const div = document.createElement('div');
          div.classList.add('item-fila');
  
          div.innerHTML = `
            <p><strong>Aluno:</strong> ${saida.nomeAluno}</p>
            <p><strong>Motivo:</strong> ${saida.motivo}</p>
            <hr>
          `;
  
          filaContainer.appendChild(div);
        });
      })
      .catch(err => {
        console.error(err);
        filaContainer.innerHTML = '<p>Erro ao carregar fila.</p>';
      });
  });
  