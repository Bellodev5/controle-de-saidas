// Elementos principais
let res = document.getElementById('res');
let atualizarS = document.getElementById('atualizarS');
let consultarID = document.getElementById('consultarID');

// Previne o recarregamento da página
document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault();
});

// Buscar aluno pelo ID
document.getElementById('aluno_id').addEventListener('blur', function() {
    let id = this.value;
    if (!id) return;
    
    fetch(`http://localhost:8081/aluno/${id}`)
    .then(res => res.json())
    .then(aluno => {
        document.getElementById('nomeAluno').value = aluno.nome + ' ' + aluno.sobrenome;
    })
    .catch(() => {
        document.getElementById('nomeAluno').value = 'Aluno não encontrado';
    });
});

// Buscar professor pelo ID
document.getElementById('professor_id').addEventListener('blur', function() {
    let id = this.value;
    if (!id) return;
    
    fetch(`http://localhost:8081/professor/${id}`)
    .then(res => res.json())
    .then(professor => {
        document.getElementById('nomeProfessor').value = professor.nome + ' ' + professor.sobrenome;
    })
    .catch(() => {
        document.getElementById('nomeProfessor').value = 'Professor não encontrado';
    });
});

// Consultar saída pelo ID (SEM RECARREGAR)
consultarID.addEventListener('click', function(e) {
    e.preventDefault();
    let saidaId = document.getElementById('codSaida').value;
    
    fetch(`http://localhost:8081/saida/${saidaId}`)
    .then(res => res.json())
    .then(saida => {
        // Preenche os campos com os dados da saída
        document.getElementById('aluno_id').value = saida.aluno_cod;
        document.getElementById('professor_id').value = saida.professor_cod;
        document.getElementById('nomeAluno').value = saida.nomeAluno;
        document.getElementById('nomeProfessor').value = saida.nomeProfessor;
        document.getElementById('motivo').value = saida.motivo;
        document.getElementById('localDestino').value = saida.localDestino;
        document.getElementById('status').value = saida.status;
        document.getElementById('dataSolicitacao').value = saida.dataSolicitacao;
        document.getElementById('horaSaida').value = saida.horaSaida;
        document.getElementById('horaRetorno').value = saida.horaRetorno;
        
        res.innerText = 'Dados carregados com sucesso!';
    })
    .catch(() => {
        res.innerText = 'Erro ao carregar saída!';
    });
});

// Atualizar saída (SEM RECARREGAR)
atualizarS.addEventListener('click', function(e) {
    e.preventDefault();
    
    let saidaId = document.getElementById('codSaida').value;
    let dados = {
        aluno_cod: document.getElementById('aluno_id').value,
        professor_cod: document.getElementById('professor_id').value,
        nomeAluno: document.getElementById('nomeAluno').value,
        nomeProfessor: document.getElementById('nomeProfessor').value,
        motivo: document.getElementById('motivo').value,
        localDestino: document.getElementById('localDestino').value,
        status: document.getElementById('status').value,
        dataSolicitacao: document.getElementById('dataSolicitacao').value,
        horaSaida: document.getElementById('horaSaida').value,
        horaRetorno: document.getElementById('horaRetorno').value
    };

    fetch(`http://localhost:8081/saida/${saidaId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dados)
    })
    .then(res => res.json())
    .then(() => {
        res.innerText = 'Saída atualizada com sucesso!';
    })
    .catch(() => {
        res.innerText = 'Erro ao atualizar saída!';
    });
});